# Islamic History (Flask) — Deploy
## Local
```
pip install -r requirements.txt
python islamic_history_app.py
# open http://127.0.0.1:5000
```
## Render.com (Free)
1. Create a new repo on GitHub and upload all files from this folder.
2. In Render, click **New > Web Service** and connect the repo.
3. Environment: Python
4. Build Command: `pip install -r requirements.txt`
5. Start Command: `gunicorn -b 0.0.0.0:$PORT islamic_history_app:app`
6. After deploy, open the URL Render gives you.

## Railway
1. New Project from GitHub repo.
2. Set Start Command to:
```
gunicorn -b 0.0.0.0:$PORT islamic_history_app:app
```
3. Deploy.
